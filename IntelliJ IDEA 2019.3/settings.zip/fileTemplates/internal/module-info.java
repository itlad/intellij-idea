#parse("File Header.java")
/**
 * @author xinghua
 * @since 1.0.0
 */
module #[[$MODULE_NAME$]]# {
}