#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
/**
 * @author xinghua
 * @since 1.0.0
 */
public enum ${NAME} {
}
