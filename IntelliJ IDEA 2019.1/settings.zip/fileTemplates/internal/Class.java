#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
/**
 *
 * @author ${USER}
 * @since 1.0.0
 */
public class ${NAME} {
}
